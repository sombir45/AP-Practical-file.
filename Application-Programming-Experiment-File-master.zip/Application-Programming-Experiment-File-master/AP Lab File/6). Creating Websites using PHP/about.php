<?php echo file_get_contents("header.html");?>
<?php echo file_get_contents("navigation.html");?>
<?php echo file_get_contents("ft.html");?>
